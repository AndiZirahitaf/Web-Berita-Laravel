<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docs</title>
</head>
<body>
    <h1>Docs</h1>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur, quia molestiae! Cum, obcaecati. Nostrum voluptatum reprehenderit perferendis ratione sequi! Illum numquam expedita doloribus reprehenderit enim officiis quisquam soluta, ut amet.</p>

    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vero doloribus enim odio adipisci esse incidunt, voluptates maxime sunt, maiores quas soluta voluptatum placeat, alias voluptate eum neque error harum magnam.</p>
</body>
</html><?php /**PATH C:\Users\LENOVO\Desktop\project\resources\views/docs.blade.php ENDPATH**/ ?>