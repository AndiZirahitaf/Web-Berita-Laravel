

<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Contact</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam minima asperiores, ducimus ad eaque vel consectetur, eveniet blanditiis id ullam obcaecati suscipit ratione, quisquam fugiat dicta? Doloremque consectetur perferendis minus.</p>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\project\resources\views/contact.blade.php ENDPATH**/ ?>