@extends('layouts.app')

@section('title', 'Home')

@section('style')
    <style>
        body{
            background-color: pink;
        }
    </style>
@endsection

@section('content')

    <div class="container">
        Halo guys, {!! $name!!} disini
    </div>
    
@endsection