@extends('layouts.app')

@section('title', 'Login')

@section('content')
    <div class="container">
        <h1>Login</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam minima asperiores, ducimus ad eaque vel consectetur, eveniet blanditiis id ullam obcaecati suscipit ratione, quisquam fugiat dicta? Doloremque consectetur perferendis minus.</p>
    </div>
    
@endsection